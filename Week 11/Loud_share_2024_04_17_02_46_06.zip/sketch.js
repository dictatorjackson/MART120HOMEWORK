    var dia2 = 15;
    var q = 50;
    var p = 50;
    var mousex = 0;
    var mousey = 0;
    var a = 30;
    var b = 60;
    var c = 100;
    var x = 50;
    var y = 50;
    var diameter = 25;
    function setup()
    {
        createCanvas(300,600);
    }
    function draw()
    {
        background(60);
        fill(900,600,0);
        circle(x,y,diameter);
       if (x > 300) {
            x = 50;
        }
        else if (x > 200) {
            x += 5;
        }
        else if (x <= 300) {
            x += 10;
        } 
        
        if (y > 300) {
            y = 50;
        }
        else if (y > 200) {
            y += 1;
        } 
        else if (y <= 300) {
            y += 3;

        }
        fill(17, 197, 226);
        square(250,0,50);

        fill(60, 50, 70);
        square(a,b,c);
       if (a > 300) {
            a = 50;
        }
        else if (a > 300) {
            a += 5;
        }
        else if (x <= 400) {
            a += 10;
        } 
        
        if (b > 400) {
            b = 50;
        }
        else if (b > 100) {
            b += 1;
        } 
        else if (b <= 400) {
            b += 3;
        }
      fill(202, 17, 226);
      circle(p, q, dia2);

      if (p >= 300) 
      {
        p = 50;
      }

      if (keyIsDown(83)) 
      {
        q += 10;
      } 
      else if (keyIsDown(87)) 
      {
        q -= 10;
      }

      if (q >= 300) 
      {
        q = 50;
      }

      if (dia2 < 200) 
      {
        dia2 += 2;
      } 
      else if (dia2 >= 200) 
      {
        dia2 = 25;
      }
      ellipse(mousex, mousey, 15, 50);

}

    function keyPressed() 
    {
      if (key == 'd') 
      {
        p += 10;
      } 
      else if (key == 'a') 
      {
        p -= 10;
      }
    }

    function mouseClicked() 
 {  
      mousex = mouseX;
      mousey = mouseY;
    
    }