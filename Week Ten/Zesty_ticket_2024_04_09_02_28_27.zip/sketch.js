let growAmount = 1;
let grow = true;
var size = 5;
var x = 200;
var y = 150;
var a = 100;
var b = 75;
var c = 130;
var d = 20;
var e = 250;
var f = 60;
var g = 280;
var h = 260;
var i = 300;
var j = 400;
var k = 300;
var l = 350;

var movement = 2;
function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  circle(x,y,y);
  if(x >= 400)
    {
       movement*=-1;
    }
    
     x += movement;
 circle(x,y,y);
  if(x <= 0)
    {
       movement*=-1;
    }
    
     y += movement;
  rect(c,x, y,f);
  if(c >= 400)
    {
       movement*=-1;
    }
    
     y += movement;
 rect(c,x,y,f);
  if(f <= 0)
    {
       movement*=-1;
    }
    
     x -= movement;
  rect(c,x, y,f);
  if(c >= 400)
    {
       movement*=-1;
    }
    
     y += movement;
 rect(c,x,y,f);
  if(f <= 0)
    {
       movement*=-1;
    }
    
     y -= movement;
  triangle(y, b, x, d, e, b);
  if(y >= 400)
    {
       movement*=-1;
    }
    
     y, b, x, d, e += movement;
  triangle(y, b, x, d, e, b);
  if(e <= 0)
    {
       movement*=-1;
    }
    
     y, b, x, d, e += movement;
  line(g, h, i, j);
  if(g >= 400)
    {
       movement*=-1;
    }
    
     x += movement;
 line(g, h, i, j);
  if(g <= 0)
    {
       movement*=-1;
    }    

    j += movement;
    h += movement;
  line(a, j, c, h);
  point(200, 200);
  point(30, 75);
  text('Jackson Quillan', 10, 30);
  textSize(size);
  text('My Self Portrait', k, l);
 if (size > 19) {
    grow = false
  }
  if (size < 12) {
    grow = true
  }
  
  if (grow == true) {
    size += growAmount
  } if (grow == false)
 {
    size -= growAmount
  }
console.log("Textsize", size)
  console.log("grow", grow)
}


