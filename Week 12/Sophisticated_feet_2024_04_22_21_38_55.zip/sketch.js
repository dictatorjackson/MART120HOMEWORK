var characterX = 100;
var characterY = 100;
var w = 87; 
var s = 83;
var a = 65;
var d = 68;
var shapeX = 30;
var shapeY = 50;
var shapeXSpeed; 
var shapeYSpeed; 
var shapeA = 70;
var shapeB = 300;
var shapeASpeed; 
var shapeBSpeed; 
var mouseShapeX;
var mouseShapeY;
function setup()
{
    createCanvas(500, 600);
    createCharacter(200,350);
}

function draw()
{
    background(100,50,300);
    stroke(0);
    fill(0);
    
    createBorders(10);
    drawCharacter();
    characterMovement();


    fill(13,145,14);
    circle(shapeX, shapeY, 10);

     shapeXSpeed = Math.floor(Math.random() * (Math.floor(Math.random() * 5)) + 1);
     shapeYSpeed = Math.floor(Math.random() * (Math.floor(Math.random() * 20)) + 1);


    fill(103,15,124);
    square(shapeA, shapeB, 20);


     shapeASpeed = Math.floor(Math.random() * (Math.floor(Math.random() * 5)) + 1);
     shapeBSpeed = Math.floor(Math.random() * (Math.floor(Math.random() * 5)) + 1);


    shapeA += shapeASpeed;
    shapeB += shapeBSpeed;
    if(shapeA > width)
    {
        shapeA = 0;
    }
    if(shapeA < 0)
    {
        shapeA = width;
    }
    if(shapeB > height)
    {
        shapeB = 0;
    }
    if(shapeB < 0)
    {
        shapeB = height;
    }
    shapeX += shapeXSpeed;
    shapeY += shapeYSpeed;
    if(shapeX > width)
    {
        shapeX = 0;
    }
    if(shapeX < 0)
    {
        shapeX = width;
    }
    if(shapeY > height)
    {
        shapeY = 0;
    }
    if(shapeY < 0)
    {
        shapeY = height;
    }

    if(characterX > width && characterY > width-50)
    {
        fill(0, 300, 300);
        stroke(5);
        textSize(26);
        text("huzzah", width/2-10, height/2-10);
    }

    fill(10,100,10);
    square(mouseShapeX, mouseShapeY, 50);

}

function characterMovement()
{

    if(keyIsDown(w))
    {
        characterY -= 20;   
    }
    if(keyIsDown(s))
    {
        characterY += 5;   
    }
    if(keyIsDown(a))
    {
        characterX -= 50;   
        console.log("movement: " + characterX);
    }
    if(keyIsDown(d))
    {
        characterX += 10;   
    }
}
function createCharacter(x,y)
{
    characterX = x;
    characterY = y;
    console.log(characterX);
    
}

function drawCharacter()
{
    fill(23,40,123);
    circle(characterX,characterY,25);
}
function createBorders(thickness)
{
    rect(0,0,width,thickness);
    rect(0,0,thickness,height);
    rect(0, height-thickness,width, thickness);
    rect(width-thickness,0,thickness,height-50);
}

function mouseClicked()
{
    mouseShapeX = mouseX;
    mouseShapeY = mouseY;
}